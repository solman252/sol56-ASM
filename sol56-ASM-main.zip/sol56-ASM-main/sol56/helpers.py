import pygame

reg_keys = {
    '0001':'a',
    '0010':'b',
    '0011':'c',
    '0100':'d',
    '0101':'res',
    '0110':'vid_r',
    '0111':'vid_g',
    '1000':'vid_b',
    '1001':'vid_addr',
}

flag_keys = {
    '0000':'s',
    '0001':'c',
    '0010':'z',
    '0011':'n',
    '0100':'o',
}

time_keys = {
    '0000':'uptime',
    '0001':'milli-second of second',
    '0010':'second of minute',
    '0011':'minute of hour',
    '0100':'hour of day',
    '0101':'day of the week',
    '0110':'day of the month',
    '0111':'day of the year',
    '1000':'month',
    '1001':'year',
}

intr_keys = {
    '00000000': 'all',
    '00010000': 'pc',
    '00100000': 'reg',
    '00100001': 'reg all',
    '00110000': 'flag',
    '00110001': 'flag all',
    '01000000': 'state',
}

keycodes = {k: i+1 for i,k in enumerate([
    pygame.K_a,             # 0x0001
    pygame.K_b,             # 0x0002
    pygame.K_c,             # 0x0003
    pygame.K_d,             # 0x0004
    pygame.K_e,             # 0x0005
    pygame.K_f,             # 0x0006
    pygame.K_g,             # 0x0007
    pygame.K_h,             # 0x0008
    pygame.K_i,             # 0x0009
    pygame.K_j,             # 0x000A
    pygame.K_k,             # 0x000B
    pygame.K_l,             # 0x000C
    pygame.K_m,             # 0x000D
    pygame.K_n,             # 0x000E
    pygame.K_o,             # 0x000F
    pygame.K_p,             # 0x0010
    pygame.K_q,             # 0x0011
    pygame.K_r,             # 0x0012
    pygame.K_s,             # 0x0013 
    pygame.K_t,             # 0x0014
    pygame.K_u,             # 0x0015
    pygame.K_v,             # 0x0016
    pygame.K_w,             # 0x0017
    pygame.K_x,             # 0x0018
    pygame.K_y,             # 0x0019
    pygame.K_z,             # 0x001A
    pygame.K_0,             # 0x001B
    pygame.K_1,             # 0x001C
    pygame.K_2,             # 0x001D
    pygame.K_3,             # 0x001E
    pygame.K_4,             # 0x001F
    pygame.K_5,             # 0x0020
    pygame.K_6,             # 0x0021
    pygame.K_7,             # 0x0022
    pygame.K_8,             # 0x0023
    pygame.K_9,             # 0x0024
    pygame.K_KP0,           # 0x0025
    pygame.K_KP1,           # 0x0026
    pygame.K_KP2,           # 0x0027
    pygame.K_KP3,           # 0x0028
    pygame.K_KP4,           # 0x0029
    pygame.K_KP5,           # 0x002A
    pygame.K_KP6,           # 0x002B
    pygame.K_KP7,           # 0x002C
    pygame.K_KP8,           # 0x002D
    pygame.K_KP9,           # 0x002E
    pygame.K_KP_ENTER,      # 0x002F
    pygame.K_KP_PLUS,       # 0x0030
    pygame.K_KP_MINUS,      # 0x0031
    pygame.K_KP_MULTIPLY,   # 0x0032
    pygame.K_KP_DIVIDE,     # 0x0033
    pygame.K_KP_PERIOD,     # 0x0034
    pygame.K_F1,            # 0x0035
    pygame.K_F2,            # 0x0036
    pygame.K_F3,            # 0x0037
    pygame.K_F4,            # 0x0038
    pygame.K_F5,            # 0x0039
    pygame.K_F6,            # 0x003A
    pygame.K_F7,            # 0x003B
    pygame.K_F8,            # 0x003C
    pygame.K_F9,            # 0x003D
    pygame.K_F10,           # 0x003E
    pygame.K_F11,           # 0x003F
    pygame.K_F12,           # 0x0040
    pygame.K_BACKQUOTE,     # 0x0041
    pygame.K_MINUS,         # 0x0042
    pygame.K_EQUALS,        # 0x0043
    pygame.K_LEFTBRACKET,   # 0x0044
    pygame.K_RIGHTBRACKET,  # 0x0045
    pygame.K_BACKSLASH,     # 0x0046
    pygame.K_SEMICOLON,     # 0x0047
    pygame.K_QUOTE,         # 0x0048
    pygame.K_COMMA,         # 0x0049
    pygame.K_PERIOD,        # 0x004A
    pygame.K_SLASH,         # 0x004B
    pygame.K_UP,            # 0x004C
    pygame.K_DOWN,          # 0x004D
    pygame.K_LEFT,          # 0x004E
    pygame.K_RIGHT,         # 0x004F
    pygame.K_LSHIFT,        # 0x0050
    pygame.K_LCTRL,         # 0x0051
    pygame.K_LALT,          # 0x0052
    pygame.K_RSHIFT,        # 0x0053
    pygame.K_RCTRL,         # 0x0054
    pygame.K_RALT,          # 0x0055
    pygame.K_ESCAPE,        # 0x0056
    pygame.K_RETURN,        # 0x0057
    pygame.K_TAB,           # 0x0058
    pygame.K_BACKSPACE,     # 0x0059
    pygame.K_SPACE,         # 0x005A
    pygame.K_CAPSLOCK,      # 0x005B
    pygame.K_NUMLOCK,       # 0x005C
    pygame.K_SCROLLOCK,     # 0x005D
    pygame.K_PRINT,         # 0x005E
    pygame.K_BREAK,         # 0x005F
    pygame.K_INSERT,        # 0x0060
    pygame.K_HOME,          # 0x0061
    pygame.K_PAGEUP,        # 0x0062
    pygame.K_DELETE,        # 0x0063
    pygame.K_END,           # 0x0064
    pygame.K_PAGEDOWN,      # 0x0065
])}